/*
 * Note: To get instruction addresses, DO NOT compile this file yourself.
 * Instead, you should disassemble the existing rtarget binary.
 */

/* This function marks the start of the farm */
int start_farm(void)
{
    return 1;
}

unsigned addval_495(unsigned x)
{
    return x + 3251079496U;
}

unsigned addval_214(unsigned x)
{
    return x + 1481505355U;
}

void setval_418(unsigned *p)
{
    *p = 2455285855U;
}

unsigned addval_359(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_383(void)
{
    return 3281016878U;
}

void setval_152(unsigned *p)
{
    *p = 3284633928U;
}

void setval_362(unsigned *p)
{
    *p = 1103335768U;
}

unsigned getval_266(void)
{
    return 2428993864U;
}

/* This function marks the middle of the farm */
int mid_farm(void)
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_425(unsigned *p)
{
    *p = 3676885385U;
}

unsigned getval_360(void)
{
    return 3374894729U;
}

void setval_479(unsigned *p)
{
    *p = 3372270217U;
}

unsigned addval_157(unsigned x)
{
    return x + 3525362317U;
}

void setval_439(unsigned *p)
{
    *p = 2425409929U;
}

unsigned getval_222(void)
{
    return 2429651233U;
}

unsigned addval_173(unsigned x)
{
    return x + 3381973385U;
}

unsigned addval_314(unsigned x)
{
    return x + 3525366157U;
}

unsigned addval_156(unsigned x)
{
    return x + 3682914729U;
}

unsigned getval_451(void)
{
    return 2430634313U;
}

unsigned addval_185(unsigned x)
{
    return x + 3531918985U;
}

void setval_493(unsigned *p)
{
    *p = 2464188744U;
}

unsigned addval_353(unsigned x)
{
    return x + 3223376267U;
}

void setval_257(unsigned *p)
{
    *p = 3526938249U;
}

unsigned addval_104(unsigned x)
{
    return x + 3677933195U;
}

unsigned addval_424(unsigned x)
{
    return x + 3531915913U;
}

void setval_394(unsigned *p)
{
    *p = 3767224327U;
}

unsigned getval_123(void)
{
    return 3286272328U;
}

void setval_494(unsigned *p)
{
    *p = 3232026249U;
}

void setval_427(unsigned *p)
{
    *p = 3222848137U;
}

unsigned getval_217(void)
{
    return 3531915905U;
}

void setval_440(unsigned *p)
{
    *p = 2425475465U;
}

unsigned addval_313(unsigned x)
{
    return x + 3224945289U;
}

unsigned getval_236(void)
{
    return 3286272328U;
}

unsigned getval_386(void)
{
    return 3224948377U;
}

unsigned getval_471(void)
{
    return 3523265161U;
}

unsigned getval_343(void)
{
    return 2464188744U;
}

void setval_355(unsigned *p)
{
    *p = 3374894729U;
}

unsigned getval_109(void)
{
    return 2447411528U;
}

unsigned addval_458(unsigned x)
{
    return x + 3374370445U;
}

void setval_192(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_121(void)
{
    return 3676881545U;
}

/* This function marks the end of the farm */
int end_farm(void)
{
    return 1;
}
